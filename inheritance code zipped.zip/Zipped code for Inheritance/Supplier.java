

public class Supplier extends Person
{
    private int yearsSpent;
    private String productsSupplied;
    

    public Supplier(int years, String products)
    {
        this.yearsSpent = years;
        this.productsSupplied = products;
    }

    public int getYearsSpent()
    {
        return this.yearsSpent;
    }
    
    public void setYearsSpent(int years)
    {
        this.yearsSpent = years;
    }
    
    public String getProductsSupplied()
    {
        return this.productsSupplied;
    }
    
    public void setProductsSupplied(String products)
    {
        this.productsSupplied = products;
    }
    
    public String toString()
    {
        
        
    }
    }
