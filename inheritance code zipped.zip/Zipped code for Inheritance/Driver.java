/** First example of using inheritance in a program - this allows a list of two types of people 
 * (customers and employees) to be inserted into the same list 
 */


import java.util.Scanner;
import java.util.ArrayList;

public class Driver extends Supplier
{
    ArrayList<Person> list;

    public Driver()
    {
        Customer c;
        list = new ArrayList<Person>();

        /** Create a list that can contain employees and customers 
         * 1. Ask user to input an employee and add it to the list
         * 2. Hardwire a new customer and add it to the list
         * 3. Ask user to input a second employee and add it to the list
         * 4. Display all of the people in the list
         */

        inputEmployee();
        c = new Customer("Tom Brown", "Dublin", "09-01-2000", 5000.0, true);
        list.add(c);
        System.out.println("\nNew Customer added to the list");
        inputEmployee();
        viewPeople();
        displayTomBrown();
        displayName();
        
        System.out.println("Number of people who have an address in Dublin is " + countAddress());
    }

    
    public void inputEmployee()
    {
        Scanner scan = new Scanner(System.in);
        String name, id, address, dob, dept;
        Employee emp;
        System.out.println("\nInputting a new employee...");

        System.out.print("\n\nEnter name for employee : ");
        name = scan.nextLine();
        System.out.print("Enter address for employee : ");
        address = scan.nextLine();
        System.out.print("Enter date of birth for employee : ");
        dob = scan.nextLine();
        System.out.print("Enter identifier for employee : ");
        id = scan.nextLine();
        System.out.print("Enter department for employee : ");
        dept = scan.nextLine();

        emp = new Employee(name,address, dob, id, dept);
        list.add(emp);

    }
    
    public void viewPeople()
    {
        System.out.println("\n\nDisplaying all customer and employees in the one list: ");
        for (Person p : list)
        {
            System.out.println(p.toString());
            System.out.println("");
        }
    }
    
    public void displayName()
    {
        System.out.println("\nDisplaying the names of people who have an address in Dublin...");
        for (Person p : list)
        {
            if(p.getAddress().equalsIgnoreCase("Dublin"))
            {
                System.out.println(p.getName());
            }
        }
    }
    
    public int countAddress()
    {
        int count = 0;
        
        for (Person p : list)
        {
            if(p.getAddress().equalsIgnoreCase("Dublin"))
            {
                count++;
            }
        }
        
        return count;
    }
    
    public void displayTomBrown()
    {
        for(Person p : list)
        {
            System.out.println(p.toString());
        }
    }
    
    
    /**********************************************/
    public static void main(String[] args)
    {
        new Driver();
    }
}
