class Person
  {

    private String name;
    private String address;
    private String dateOfBirth;

    //constructors 
    public Person()
    {
        this.name = "";
        this.address = "";
        this.dateOfBirth = "";
    }

    public Person(String n, String a, String dob)
    {
        this.name = n;
        this.address = a;
        this.dateOfBirth = dob;
    }

    public String getName()
    {
        return this.name;
    }

    public void setName (String n)
    {
        this.name = n;
    }

    public String getAddress()
    {
        return this.address;
    }

    public void setAddress (String a)
    {
        this.address = a;
    }

    public String getDOB()
    {
        return this.dateOfBirth;
    }

    public void setDOB (String dob)
    {
        this.dateOfBirth = dob;
    }

    public String toString()
    {
        return "\nName = " + this.name + "\nAddress = " + this.address +
        "\nDOB = " + this.dateOfBirth;
    }

}