
/**
 *Employee - inherits from Person
 */
public class Employee extends Person
{
    public String identifier;
    public String dept;
    
    public Employee()
    {
        /** Call the blank Person constructor */
        super(); //call the superclass constructor
        this.identifier = "";
        this.dept = "";
        
    }
    
    public Employee(String name, String add, String dob, String id, String dept)
    {
        /** Call the regular Person constructor */
        super(name,add, dob); //call the superclass constructor
        this.identifier = id;
        this.dept = dept;
    }
    public void setIdentifier(String i)
    {
        this.identifier = i;
    }
    
    public String getIdentifier()
    {
        return this.identifier;
    }
    
    public void setDepartment(String d)
    {
        this.dept = d;
    }
    
    public String getDepartment()
    {
        return this.dept;
    }
    
    public String toString()
    {
        String result = "\nDisplay Employee details " + 
        "\nIdentifier: " + this.identifier + super.toString()+
        "\nDepartment: " + this.dept;
        
        return result;
    }

    public void displayEmp()
    {
        System.out.print("\f");
        System.out.println(toString());
    }
    
    public void displayName()
    {
        System.out.println("Name : " + super.getName());
    }
}
