
public class Customer extends Person
{
    private double amountSpent;
    private boolean isLoyal;

    public Customer(String name, String addr, String dob, double bal, boolean loyal)
    {
        super(name, addr, dob);
        this.amountSpent = bal;
        this.isLoyal = loyal;

    }

    public double getAmountSpent()
    {
        return this.amountSpent;
    }
    
    public boolean isLoyal()
    {
        return this.isLoyal;
    }
    
    public void setAmountSpent(double amount)
    {
        this.amountSpent = amount;
    }
    
    public void setIsLoyal(boolean loyalty)
    {
        this.isLoyal = loyalty;
    }
    public String toString()
    {
        String result = null;
        result = "\n Display Customer details \n" + super.toString() + "\n" + 
        "Amount spent by customer : " + this.amountSpent + "\n"; 
        if (this.isLoyal)
            result = result + "Loyal customer entitled to discounts" + "\n";
        else
            result = result + "Occasional customer" + "\n";

        return result;
    }
}
